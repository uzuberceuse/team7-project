package sparta.AIBusinessProject.domain.order.entity;

public enum OrderTypeEnum {
    ONLINE, OFFLINE
}


