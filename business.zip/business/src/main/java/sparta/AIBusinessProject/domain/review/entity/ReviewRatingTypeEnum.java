package sparta.AIBusinessProject.domain.review.entity;

public enum ReviewRatingTypeEnum {
    ONE, TWO, THREE, FOUR, FIVE
}
